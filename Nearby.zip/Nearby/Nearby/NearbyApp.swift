//
//  NearbyApp.swift
//  Nearby
//
//  Created by Rupal Gautam on 17/03/24.
//

import SwiftUI

@main
struct NearbyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
