//
//  ContentView.swift
//  Nearby
//
//  Created by Rupal Gautam on 17/03/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VenueListView(viewModel: VenueListViewModel())
    }
}
